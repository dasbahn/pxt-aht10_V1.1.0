# AHT10 Erweiterung für MakeCode (micro:bit / Calliope mini)

MakeCode‑Erweiterung für den **AHT10** Temperatur‑ und Luftfeuchtigkeitssensor über **I²C** (Standardadresse `0x38` / dezimal `56`).  
Unterstützt Messung von **Temperatur (°C/°F)** und **relativer Luftfeuchte (%)** sowie abgeleitete Größen **Taupunkt (°C)** und **Heat Index (°C)**.

---

## Installation

**Variante A – Release‑Tag (empfohlen)**  
MakeCode → **Erweiterungen** → **Erweiterung hinzufügen** → **GitHub‑URL**:

```
https://github.com/dasbahn/pxt-aht10_V1.0.8#v1.1.0
```

> Nutze idealerweise immer einen **Release‑Tag** (z. B. `v1.1.0`) oder einen **Commit‑SHA**, damit MakeCode einen definierten Stand lädt.

**Variante B – Commit‑SHA (maximale Zuverlässigkeit)**  
Importiere mit:
```
https://github.com/dasbahn/pxt-aht10_V1.0.8#<DEIN_COMMIT_SHA>
```

Falls der Editor ältere Metadaten zeigt:  
**Zahnrad → Über → Reset** und danach **Strg+F5** (Hard Reload), anschließend die Erweiterung neu importieren.

---

## Verdrahtung

- **VCC** → **3.3 V** (kein 5 V am micro:bit/Calliope!)  
- **GND** → **GND**  
- **SDA** → **P20**  
- **SCL** → **P19**  
- I²C‑Adresse: **`0x38`** (dez. **56**) – Standard beim AHT10  
- Pull‑Ups: bei den meisten Breakout‑Boards vorhanden; sonst 4.7–10 kΩ auf SDA/SCL nach 3.3 V

---

## Blöcke / API

### Initialisierung
- **AHT10 initialisieren an Adresse `%address`**  
  Führt Soft‑Reset und Kalibrierung aus. Einmal beim Start aufrufen.

### Messwerte
- **AHT10 Temperatur (°C) an Adresse `%address`** → `number`
- **AHT10 Temperatur (°F) an Adresse `%address`** → `number`
- **AHT10 Luftfeuchtigkeit in Prozent an Adresse `%address`** → `number`

### Abgeleitete Größen (aus T/Feuchte berechnet)
- **AHT10 Taupunkt (°C) an Adresse `%address`** → `number`  
  *Taupunkt* ist die Temperatur, bei der die Luft **gesättigt** ist (RH=100 %).
- **AHT10 Heat Index (°C) an Adresse `%address`** → `number`  
  *Heat Index* ist die **gefühlte Temperatur** bei hoher Luftfeuchte (NOAA‑Formeln).

### Wartung / Debug
- **AHT10 Soft‑Reset an Adresse `%address`**  
- **AHT10 Rohbytes dumpen an Adresse `%address`** (seriell)  
  → Gibt die 6 Datenbytes und berechnete Werte zu Diagnosezwecken aus.

---

## Beispiele

### Block‑Beispiel
- Beim **Start**: `AHT10 initialisieren (0x38)`
- In **Dauerhaft**:
  - `zeige Zahl (AHT10 Temperatur (°C) an Adresse 0x38)`
  - `zeige Zahl (AHT10 Luftfeuchtigkeit in Prozent an Adresse 0x38)`

### TypeScript‑Beispiel
```ts
AHT10.initialize(0x38)
basic.forever(function () {
    const t = Math.round(AHT10.temperatureC(0x38))
    const h = Math.round(AHT10.humidity(0x38))
    serial.writeLine("T=" + t + "C  H=" + h + "%")
    basic.pause(1000)
})
```

---

## Hinweise & Best Practices

- **Messintervall**: 5–10 Hz ist ausreichend (eine Messung dauert intern ~80–120 ms).  
- **Erste Schritte**: Immer **initialisieren** (Start‑Block), danach messen.  
- **Feuchte = 0 %?**  
  - Prüfe die Verdrahtung (SDA/SCL/GND/3.3 V),  
  - erhöhe die Wartezeit zwischen Messungen (z. B. 100–150 ms),  
  - nutze einmal `Soft‑Reset`.  
- **Adresse**: Du kannst dezimal (`56`) oder hex (`0x38`) eingeben.  
- **Kompatibilität**: micro:bit V1/V2 und Calliope mini (I²C: P19/P20).

---

## Technische Details

- **I²C‑Adresse**: `0x38` (7‑Bit)  
- **Init/Cal**: `E1 08 00` (+ optional `BA` Soft‑Reset)  
- **Messung**: `AC 33 00`, danach Busy‑Polling bis Status‑Bit7=0  
- **Rohdaten (20‑Bit)**:  
  - **Feuchte**: `(buf[1] << 12) | (buf[2] << 4) | (buf[3] >> 4)`  
  - **Temperatur**: `((buf[3] & 0x0F) << 16) | (buf[4] << 8) | buf[5]`  
- **Umrechnung**:  
  - **Feuchte (%)**: `rawHum * 100 / 2^20`  
  - **Temp (°C)**: `rawTemp * 200 / 2^20 - 50`

---

## Projektstruktur

```
/
├─ AHT10.ts         // Erweiterungscode (Blöcke, I²C, Umrechnung)
├─ README.md        // diese Datei
├─ LICENSE          // MIT Lizenz (alternativ: LICENSE.txt)
├─ test.ts          // Build-Schnelltest für 'pxt deploy'
└─ icon.png         // 300×200 px, <100 KB (für MakeCode-Katalog)
```

> **Hinweis:** Achte auf die **exakte Groß-/Kleinschreibung** der Datei `AHT10.ts`, wie sie im Repo ist, und referenziere sie so in `pxt.json`.

---

## `pxt.json` (Beispiel)

> Passe die `files` und die Version an deinen Stand an.

```json
{
  "name": "pxt-aht10",
  "version": "1.1.0",
  "description": "AHT10 Temperatur- und Feuchtigkeitssensor für BBC micro:bit / Calliope (MakeCode), I2C @ 0x38",
  "license": "MIT",
  "dependencies": { "core": "*" },
  "files": ["AHT10.ts", "README.md", "test.ts"],
  "icon": "icon.png",
  "public": true
}
```

---

## Checkliste für die Veröffentlichung (MakeCode Review)

- [ ] **Release erstellt** (`vMAJOR.MINOR.PATCH`, z. B. `v1.1.0`)  
- [ ] **Lizenz (MIT)** im Root (`LICENSE` oder `LICENSE.txt`)  
- [ ] **`icon.png`** im Root (300×200, <100 KB), in `pxt.json` referenziert  
- [ ] **Repo‑Beschreibung / Topics** gesetzt (z. B. `makecode`, `microbit`, `calliope`, `aht10`, `i2c`, `sensor`)  
- [ ] **`test.ts`** vorhanden und kompiliert mit `pxt deploy`  
- [ ] **README** mit API‑Doku (Blöcke, Beispiele, Verdrahtung)  
- [ ] **Benennungskonventionen** eingehalten (Namespace `AHT10`, camelCase‑Funktionen, eindeutige `blockId`s, klare Blocktexte ohne `%`‑Kollision)

---

## Lizenz

Dieses Projekt ist unter der **MIT‑Lizenz** veröffentlicht. Siehe Datei `LICENSE`.
